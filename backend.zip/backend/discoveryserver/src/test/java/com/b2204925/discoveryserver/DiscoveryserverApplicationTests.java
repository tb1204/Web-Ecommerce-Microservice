package com.b2204925.discoveryserver;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DiscoveryserverApplicationTests {

    @Test
    void contextLoads() {
    }

}
